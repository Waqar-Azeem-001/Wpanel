GRANT USAGE ON *.* TO 'acmeuser_shop'@'localhost' IDENTIFIED BY PASSWORD '*2470C0C06DEE42FD1618BB99005ADCA2EC9D1E19';
GRANT ALL PRIVILEGES ON `acmeuser\_shop`.* TO 'acmeuser_shop'@'localhost';
