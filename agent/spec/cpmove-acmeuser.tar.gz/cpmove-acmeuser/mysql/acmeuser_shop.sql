-- MySQL dump
CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;
INSERT INTO `orders` VALUES (1,'Ann'),(2,'O\'Neil'),(3,NULL);
