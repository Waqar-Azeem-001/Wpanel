documentroot: /home/acmeuser/public_html
phpversion: ea-php74
