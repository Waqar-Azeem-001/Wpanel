<?php
/* Front to the blog */
require __DIR__ . '/wp-blog-header.php';
